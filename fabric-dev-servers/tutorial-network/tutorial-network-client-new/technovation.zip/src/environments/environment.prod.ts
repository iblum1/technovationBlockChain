export const environment = {
  production: true,
  baseUrl: 'http://10.255.110.86:3000/api/'
};
